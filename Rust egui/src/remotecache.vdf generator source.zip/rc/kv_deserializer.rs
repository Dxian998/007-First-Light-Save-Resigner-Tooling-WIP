use super::kv_tokenizer::KvTokenizer;

#[derive(Debug, Clone)]
pub enum KvNode {
    Pair(KvPair),
    Group(KvGroup),
}

#[derive(Debug, Clone)]
pub struct KvPair {
    pub key: String,
    pub value: String,
}

#[derive(Debug, Clone)]
pub struct KvGroup {
    pub key: String,
    pub nodes: Vec<KvNode>,
}

impl KvPair {
    pub fn new(key: impl Into<String>, value: impl Into<String>) -> Self {
        Self { key: key.into(), value: value.into() }
    }
}

impl KvGroup {
    pub fn new(key: impl Into<String>) -> Self {
        Self { key: key.into(), nodes: Vec::new() }
    }
}

pub struct KvDeserializer;

impl KvDeserializer {
    pub fn deserialize(text: &str) -> Result<KvGroup, String> {
        let mut tokenizer = KvTokenizer::new(text);
        Self::parse_group(&mut tokenizer, None)
    }

    fn parse_group(t: &mut KvTokenizer, k: Option<String>) -> Result<KvGroup, String> {
        let group_name = match k {
            Some(name) => name,
            None => t.read_string()?,
        };
        let mut group = KvGroup::new(group_name);

        t.read_symbol('{')?;

        while !t.peek_symbol('}') {
            let key = t.read_string()?;

            if t.peek_symbol('{') {
                group.nodes.push(KvNode::Group(Self::parse_group(t, Some(key))?));
            } else {
                let value = t.read_string()?;
                group.nodes.push(KvNode::Pair(KvPair::new(key, value)));
            }
        }

        t.read_symbol('}')?;
        Ok(group)
    }
}

use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};
use sha1::{Sha1, Digest};
use super::kv_deserializer::{KvGroup, KvNode, KvPair};

const DEFAULT_SHA: &str = "0000000000000000000000000000000000000000";

pub struct CachedFileMetadata {
    pub relative_path: String,
    pub root: i32,
    pub size: i32,
    pub local_time: i64,
    pub time: i64,
    pub remote_time: i64,
    pub sha: String,
    pub sync_state: i32,
    pub persist_state: i32,
    pub platforms_to_sync2: i32,
}

impl CachedFileMetadata {
    pub fn new(relative_path: impl Into<String>) -> Self {
        Self {
            relative_path: relative_path.into(),
            root: 0,
            size: 0,
            local_time: 0,
            time: 0,
            remote_time: 0,
            sha: DEFAULT_SHA.to_string(),
            sync_state: 0,
            persist_state: 0,
            platforms_to_sync2: -1,
        }
    }

    pub fn from_file(file_path: &str, root_path: &str) -> Result<Self, String> {
        if !Path::new(file_path).exists() {
            return Err(format!("File not found: {}", file_path));
        }

        let relative_path = Self::get_relative_path(file_path, root_path)?;
        let mut metadata = Self::new(relative_path);

        let data = std::fs::read(file_path).map_err(|e| e.to_string())?;
        metadata.size = data.len() as i32;
        metadata.set_local_time_and_time_to_now();
        metadata.sha = Self::sha1_from_bytes(&data);

        Ok(metadata)
    }

    pub fn from_kv_group(group: &KvGroup) -> Self {
        let mut metadata = Self::new(&group.key);

        for node in &group.nodes {
            if let KvNode::Pair(pair) = node {
                match pair.key.as_str() {
                    "root"             => metadata.root             = safe_parse_int(&pair.value),
                    "size"             => metadata.size             = safe_parse_int(&pair.value),
                    "localtime"        => metadata.local_time       = safe_parse_long(&pair.value),
                    "time"             => metadata.time             = safe_parse_long(&pair.value),
                    "remotetime"       => metadata.remote_time      = safe_parse_long(&pair.value),
                    "sha"              => metadata.sha              = pair.value.clone(),
                    "syncstate"        => metadata.sync_state       = safe_parse_int(&pair.value),
                    "persiststate"     => metadata.persist_state    = safe_parse_int(&pair.value),
                    "platformstosync2" => metadata.platforms_to_sync2 = safe_parse_int(&pair.value),
                    _ => {}
                }
            }
        }

        metadata
    }

    fn now() -> i64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64
    }

    fn sha1_from_bytes(data: &[u8]) -> String {
        let mut hasher = Sha1::new();
        hasher.update(data);
        hasher.finalize().iter().map(|b| format!("{:02x}", b)).collect()
    }

    fn get_relative_path(file_path: &str, root_path: &str) -> Result<String, String> {
        let file = Path::new(file_path);
        let root = Path::new(root_path);
        file.strip_prefix(root)
            .map(|p| p.to_string_lossy().replace(std::path::MAIN_SEPARATOR, "/"))
            .map_err(|e| e.to_string())
    }

    pub fn set_local_time_to_now(&mut self) {
        self.local_time = Self::now();
    }

    pub fn set_time_to_now(&mut self) {
        self.time = Self::now();
    }

    pub fn set_local_time_and_time_to_now(&mut self) {
        let epoch = Self::now();
        self.local_time = epoch;
        self.time = epoch;
    }

    pub fn set_local_time(&mut self, timestamp: i64) {
        self.local_time = timestamp;
    }

    pub fn set_time(&mut self, timestamp: i64) {
        self.time = timestamp;
    }

    pub fn set_local_time_and_time(&mut self, timestamp: i64) {
        self.local_time = timestamp;
        self.time = timestamp;
    }

    pub fn get_local_date_time(&self) -> i64 {
        self.local_time
    }

    pub fn get_date_time(&self) -> i64 {
        self.time
    }

    pub fn get_remote_date_time(&self) -> i64 {
        self.remote_time
    }

    pub fn export_as_kv_group(&self) -> KvGroup {
        let mut group = KvGroup::new(&self.relative_path);
        group.nodes.push(KvNode::Pair(KvPair::new("root",             self.root.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("size",             self.size.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("localtime",        self.local_time.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("time",             self.time.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("remotetime",       self.remote_time.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("sha",              self.sha.clone())));
        group.nodes.push(KvNode::Pair(KvPair::new("syncstate",        self.sync_state.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("persiststate",     self.persist_state.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("platformstosync2", self.platforms_to_sync2.to_string())));
        group
    }
}

fn safe_parse_int(s: &str) -> i32 {
    s.parse().unwrap_or(0)
}

fn safe_parse_long(s: &str) -> i64 {
    s.parse().unwrap_or(0)
}
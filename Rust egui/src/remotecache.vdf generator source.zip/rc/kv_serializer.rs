use super::kv_deserializer::{KvGroup, KvNode};

pub struct KvSerializer;

impl KvSerializer {
    pub fn serialize(group: &KvGroup) -> String {
        let mut sb = String::new();
        Self::serialize_group(group, &mut sb, 0);
        sb
    }

    fn serialize_group(group: &KvGroup, sb: &mut String, indent: usize) {
        const PAD_CHAR: char = '\t';
        let pad = PAD_CHAR.to_string().repeat(indent);

        sb.push_str(&format!("{}\"{}\"\n", pad, group.key));
        sb.push_str(&format!("{}{{\n", pad));

        for node in &group.nodes {
            match node {
                KvNode::Pair(pair) => {
                    sb.push_str(&format!(
                        "{}{}\"{}\"{}{}\"{}\"\n",
                        pad, PAD_CHAR, pair.key, PAD_CHAR, PAD_CHAR, pair.value
                    ));
                }
                KvNode::Group(child_group) => {
                    Self::serialize_group(child_group, sb, indent + 1);
                }
            }
        }

        sb.push_str(&format!("{}}}\n", pad));
    }
}

pub struct KvTokenizer {
    text: Vec<char>,
    pos: usize,
}

impl KvTokenizer {
    pub fn new(text: &str) -> Self {
        Self {
            text: text.chars().collect(),
            pos: 0,
        }
    }

    pub fn peek_symbol(&mut self, c: char) -> bool {
        self.skip_whitespace();
        self.pos < self.text.len() && self.text[self.pos] == c
    }

    pub fn read_symbol(&mut self, c: char) -> Result<(), String> {
        self.skip_whitespace();
        if self.pos >= self.text.len() || self.text[self.pos] != c {
            return Err(format!("Expected '{}' at position {}", c, self.pos));
        }
        self.pos += 1;
        Ok(())
    }

    pub fn read_string(&mut self) -> Result<String, String> {
        self.skip_whitespace();

        if self.pos >= self.text.len() || self.text[self.pos] != '"' {
            let found = self.text.get(self.pos).copied().unwrap_or('\0');
            return Err(format!(
                "Expected '\"' at position {}, but found '{}'!",
                self.pos, found
            ));
        }

        self.pos += 1; // skip opening quote
        let start = self.pos;

        while self.pos < self.text.len() && self.text[self.pos] != '"' {
            self.pos += 1;
        }

        if self.pos >= self.text.len() {
            return Err("Unterminated string literal!".to_string());
        }

        let result: String = self.text[start..self.pos].iter().collect();
        self.pos += 1; // skip closing quote

        Ok(result)
    }

    fn skip_whitespace(&mut self) {
        while self.pos < self.text.len() {
            match self.text[self.pos] {
                ' ' | '\t' | '\n' | '\r' => self.pos += 1,
                _ => break,
            }
        }
    }
}

use std::path::Path;
use super::kv_deserializer::{KvGroup, KvNode, KvPair};
use super::kv_serializer::KvSerializer;
use super::cached_file_metadata::CachedFileMetadata;

pub const FILE_NAME: &str = "remotecache";
pub const FILE_EXTENSION: &str = ".vdf";

pub struct RemoteCacheVdfFile {
    pub app_id: i32,
    pub change_number: i32,
    pub os_type: i32,
    pub cached_files: Vec<CachedFileMetadata>,
}

impl RemoteCacheVdfFile {
    pub fn new(app_id: i32) -> Self {
        Self {
            app_id,
            change_number: 0,
            os_type: 0,
            cached_files: Vec::new(),
        }
    }

    pub fn from_folder(remote_folder_path: &str) -> Result<Self, String> {
        let app_id = Self::get_app_id_from_path(remote_folder_path)?;
        let mut vdf = Self::new(app_id);

        let files = Self::get_all_files(remote_folder_path)?;
        for file in files {
            let metadata = CachedFileMetadata::from_file(&file, remote_folder_path)?;
            vdf.cached_files.push(metadata);
        }

        Ok(vdf)
    }

    pub fn from_kv_group(group: &KvGroup) -> Result<Self, String> {
        let app_id: i32 = group.key.parse().map_err(|_| "Invalid AppId in group key".to_string())?;
        let mut vdf = Self::new(app_id);

        for node in &group.nodes {
            match node {
                KvNode::Group(file_group) => {
                    vdf.cached_files.push(CachedFileMetadata::from_kv_group(file_group));
                }
                KvNode::Pair(pair) => {
                    match pair.key.as_str() {
                        "ChangeNumber" => vdf.change_number = pair.value.parse().unwrap_or(0),
                        "OSType"       => vdf.os_type       = pair.value.parse().unwrap_or(0),
                        _ => {}
                    }
                }
            }
        }

        Ok(vdf)
    }

    fn get_app_id_from_path(path: &str) -> Result<i32, String> {
        Path::new(path)
            .parent()
            .and_then(|p| p.file_name())
            .and_then(|n| n.to_str())
            .and_then(|s| s.parse::<i32>().ok())
            .ok_or_else(|| "Invalid Directory".to_string())
    }

    fn get_all_files(dir: &str) -> Result<Vec<String>, String> {
        let mut files = Vec::new();
        Self::walk_dir(dir, &mut files).map_err(|e| e.to_string())?;
        Ok(files)
    }

    fn walk_dir(dir: &str, files: &mut Vec<String>) -> std::io::Result<()> {
        for entry in std::fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.is_dir() {
                Self::walk_dir(path.to_str().unwrap_or(""), files)?;
            } else {
                let filename = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
                if filename != format!("{}{}", FILE_NAME, FILE_EXTENSION) {
                    files.push(path.to_string_lossy().to_string());
                }
            }
        }
        Ok(())
    }

    pub fn export_as_kv_group(&self) -> KvGroup {
        let mut group = KvGroup::new(self.app_id.to_string());
        group.nodes.push(KvNode::Pair(KvPair::new("ChangeNumber", self.change_number.to_string())));
        group.nodes.push(KvNode::Pair(KvPair::new("OSType",       self.os_type.to_string())));

        for cached_file in &self.cached_files {
            group.nodes.push(KvNode::Group(cached_file.export_as_kv_group()));
        }

        group
    }

    pub fn export_as_file(&self, remote_folder: &str) -> Result<(), String> {
        let kv = self.export_as_kv_group();
        let serialized = KvSerializer::serialize(&kv);
        
        // Output TO the parent of the 'remote' folder
        let parent = Path::new(remote_folder)
            .parent()
            .ok_or_else(|| "Could not find parent directory for export".to_string())?;

        let output_path = parent.join(format!("{}{}", FILE_NAME, FILE_EXTENSION));
        
        std::fs::write(&output_path, serialized.as_bytes()).map_err(|e| e.to_string())
    }
}